import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {

        Pacijent p = new Pacijent(1, "Milan", "Jovanovic", "milan@gmail.com", "milan123", "ZD123456");
        Lekar l = new Lekar(2, "Dragan", "Petrovic", "dragan@bolnica.rs", "lekar123", "Dermatolog");

        Termin t = new Termin(1, l.id, p.id, LocalDateTime.now().plusDays(1), "zakazan");
        
        System.out.println("Zakazan termin kod lekara " + l.getIme() + " za pacijenta " + p.getIme());
        System.out.println("Datum: " + t.getDatumVreme() + ", Status: " + t.getStatus());
    }
}
