public abstract class Korisnik {
    protected int id;
    protected String ime;
    protected String prezime;
    protected String email;
    protected String lozinka;

    public Korisnik(int id, String ime, String prezime, String email, String lozinka) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.email = email;
        this.lozinka = lozinka;
    }

    public String getIme() { return ime; }
    public String getEmail() { return email; }
    public String getLozinka() { return lozinka; }
}
