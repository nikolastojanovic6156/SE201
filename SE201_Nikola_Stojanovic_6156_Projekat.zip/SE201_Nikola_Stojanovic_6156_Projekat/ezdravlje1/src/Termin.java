import java.time.LocalDateTime;

public class Termin {
    private int id;
    private int lekarId;
    private int pacijentId;
    private LocalDateTime datumVreme;
    private String status;

    public Termin(int id, int lekarId, int pacijentId, LocalDateTime datumVreme, String status) {
        this.id = id;
        this.lekarId = lekarId;
        this.pacijentId = pacijentId;
        this.datumVreme = datumVreme;
        this.status = status;
    }

    public int getLekarId() { return lekarId; }
    public int getPacijentId() { return pacijentId; }
    public LocalDateTime getDatumVreme() { return datumVreme; }
    public String getStatus() { return status; }
}
