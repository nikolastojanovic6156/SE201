import java.time.LocalDateTime;

public class Pregled {
    private int id;
    private int lekarId;
    private int pacijentId;
    private LocalDateTime datum;
    private String izvestaj;

    public Pregled(int id, int lekarId, int pacijentId, LocalDateTime datum, String izvestaj) {
        this.id = id;
        this.lekarId = lekarId;
        this.pacijentId = pacijentId;
        this.datum = datum;
        this.izvestaj = izvestaj;
    }

    public String getIzvestaj() { return izvestaj; }
    public LocalDateTime getDatum() { return datum; }
}
