public class Obavestenje {
    private int id;
    private String tekst;
    private String emailPrimaoca;

    public Obavestenje(int id, String tekst, String emailPrimaoca) {
        this.id = id;
        this.tekst = tekst;
        this.emailPrimaoca = emailPrimaoca;
    }

    public String getTekst() { return tekst; }
    public String getEmailPrimaoca() { return emailPrimaoca; }
}
