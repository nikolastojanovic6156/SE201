public class Lekar extends Korisnik {
    private String specijalizacija;

    public Lekar(int id, String ime, String prezime, String email, String lozinka, String specijalizacija) {
        super(id, ime, prezime, email, lozinka);
        this.specijalizacija = specijalizacija;
    }

    public String getSpecijalizacija() {
        return specijalizacija;
    }
}
