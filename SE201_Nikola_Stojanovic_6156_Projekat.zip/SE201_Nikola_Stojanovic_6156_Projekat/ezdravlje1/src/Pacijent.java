public class Pacijent extends Korisnik {
    private String zdravstveniBroj;

    public Pacijent(int id, String ime, String prezime, String email, String lozinka, String zdravstveniBroj) {
        super(id, ime, prezime, email, lozinka);
        this.zdravstveniBroj = zdravstveniBroj;
    }

    public String getZdravstveniBroj() {
        return zdravstveniBroj;
    }
}
