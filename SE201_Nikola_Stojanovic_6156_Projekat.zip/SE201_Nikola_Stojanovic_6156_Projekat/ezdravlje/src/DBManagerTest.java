import org.junit.jupiter.api.*;
import java.sql.*;
import static org.junit.jupiter.api.Assertions.*;

public class DBManagerTest {
    private static DBManager db;

    @BeforeAll
    public static void setUp() throws SQLException {
        db = new DBManager();
    }

    @AfterAll
    public static void tearDown() throws SQLException {
        db.zatvori();
    }

    @Test
    public void testProveriLoginTacniPodaci() throws SQLException {
        assertTrue(db.proveriLogin("marko@gmail.com", "lozinka123"));
    }

    @Test
    public void testProveriLoginNetacniPodaci() throws SQLException {
        assertFalse(db.proveriLogin("nepostoji@gmail.com", "pogresno"));
    }

    @Test
    public void testZakaziTermin() throws SQLException {
        db.zakaziTermin(1, 1, "2025-06-15 14:00:00");
        assertTrue(true);
    }
}
