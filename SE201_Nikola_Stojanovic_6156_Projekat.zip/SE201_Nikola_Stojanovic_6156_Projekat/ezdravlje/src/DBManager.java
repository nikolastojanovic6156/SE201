import java.sql.*;

public class DBManager {
    private static final String URL = "jdbc:mysql://localhost:3306/ezdravlje";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private Connection conn;

    public DBManager() throws SQLException {
        conn = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public void zakaziTermin(int lekarId, int pacijentId, String datum) throws SQLException {
        String sql = "INSERT INTO termin (lekar_id, pacijent_id, datum, status) VALUES (?, ?, ?, 'zakazan')";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, lekarId);
            stmt.setInt(2, pacijentId);
            stmt.setString(3, datum);
            stmt.executeUpdate();
        }
    }

    public boolean proveriLogin(String email, String lozinka) throws SQLException {
        String sql = "SELECT * FROM korisnik WHERE email = ? AND lozinka = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, lozinka);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

    public void zatvori() throws SQLException {
        if (conn != null) conn.close();
    }
}
