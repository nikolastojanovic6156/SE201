public class Main {
    public static void main(String[] args) {
        try {
            DBManager db = new DBManager();

            String email = "marko@gmail.com";
            String[] lozinke = {"pogresna1", "pogresna2", "lozinka123", "pogresna3"};
            int maxPokusaja = 2;
            int brojPokusaja = 0;
            boolean uspeh = false;

            for (String pokusaj : lozinke) {
                brojPokusaja++;
                if (brojPokusaja > maxPokusaja) {
                    System.out.println("Pristup blokiran zbog previše neuspešnih pokušaja!");
                    break;
                }

                if (db.proveriLogin(email, pokusaj)) {
                    System.out.println("Uspešno prijavljivanje! Lozinka: " + pokusaj);
                    uspeh = true;
                    break;
                } else {
                    System.out.println("Neuspešan pokušaj #" + brojPokusaja + " za lozinku: " + pokusaj);
                }
            }

            if (!uspeh && brojPokusaja <= maxPokusaja) {
                System.out.println("Nijedna lozinka nije tačna.");
            }

            db.zatvori();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
