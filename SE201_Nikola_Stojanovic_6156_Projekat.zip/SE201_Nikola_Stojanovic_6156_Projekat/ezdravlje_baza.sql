
-- Kreiranje baze
CREATE DATABASE IF NOT EXISTS ezdravlje;
USE ezdravlje;

-- Tabela korisnik
CREATE TABLE korisnik (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ime VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    lozinka VARCHAR(255),
    uloga ENUM('pacijent', 'lekar', 'admin') NOT NULL
);

-- Tabela pacijent
CREATE TABLE pacijent (
    id INT AUTO_INCREMENT PRIMARY KEY,
    korisnik_id INT,
    zdravstveni_broj VARCHAR(20),
    FOREIGN KEY (korisnik_id) REFERENCES korisnik(id)
);

-- Tabela lekar
CREATE TABLE lekar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    korisnik_id INT,
    specijalizacija VARCHAR(100),
    FOREIGN KEY (korisnik_id) REFERENCES korisnik(id)
);

-- Tabela termin
CREATE TABLE termin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lekar_id INT,
    pacijent_id INT,
    datum DATETIME,
    status ENUM('zakazan', 'otkazan') DEFAULT 'zakazan',
    FOREIGN KEY (lekar_id) REFERENCES lekar(id),
    FOREIGN KEY (pacijent_id) REFERENCES pacijent(id)
);

-- Tabela obavestenje
CREATE TABLE obavestenje (
    id INT AUTO_INCREMENT PRIMARY KEY,
    korisnik_id INT,
    tekst TEXT,
    FOREIGN KEY (korisnik_id) REFERENCES korisnik(id)
);

-- Tabela pregled
CREATE TABLE pregled (
    id INT AUTO_INCREMENT PRIMARY KEY,
    termin_id INT,
    opis TEXT,
    FOREIGN KEY (termin_id) REFERENCES termin(id)
);

-- Unos test korisnika
INSERT INTO korisnik (ime, email, lozinka, uloga) VALUES 
('Marko Petrović', 'marko@gmail.com', 'lozinka123', 'pacijent'),
('Jelena Đorđević', 'jelena@gmail.com', 'lekarka123', 'lekar'),
('Ana Stanić', 'admin@gmail.com', 'admin123', 'admin');

-- Unos pacijenta i lekara
INSERT INTO pacijent (korisnik_id, zdravstveni_broj) VALUES (1, '123456789');
INSERT INTO lekar (korisnik_id, specijalizacija) VALUES (2, 'Opšta medicina');

-- Unos termina
INSERT INTO termin (lekar_id, pacijent_id, datum, status) VALUES (1, 1, '2025-06-10 10:00:00', 'zakazan');

-- Unos obaveštenja
INSERT INTO obavestenje (korisnik_id, tekst) VALUES (1, 'Vaš pregled je zakazan za 10. jun u 10:00h.');

-- Unos pregleda
INSERT INTO pregled (termin_id, opis) VALUES (1, 'Pacijent se žali na glavobolju.');
