
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;

public class PDFGenerator {

    public static void generisiIzvestaj(String imePacijenta, String imeLekara, String izvestaj, String fajlPutanja) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(fajlPutanja));
            document.open();

            Font naslovFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
            Font tekstFont = new Font(Font.FontFamily.HELVETICA, 12);

            Paragraph naslov = new Paragraph("Izveštaj o pregledu", naslovFont);
            naslov.setAlignment(Element.ALIGN_CENTER);
            document.add(naslov);

            document.add(new Paragraph(" "));
            document.add(new Paragraph("Pacijent: " + imePacijenta, tekstFont));
            document.add(new Paragraph("Lekar: " + imeLekara, tekstFont));
            document.add(new Paragraph("Izveštaj: ", tekstFont));
            document.add(new Paragraph(izvestaj, tekstFont));

        } catch (Exception e) {
            System.out.println("Greška pri generisanju PDF-a: " + e.getMessage());
        } finally {
            document.close();
        }
    }

    public static void main(String[] args) {
        generisiIzvestaj("Milan Jovanović", "Dr Ana Petrović", "Pregled je protekao bez problema. Pacijent u dobrom stanju.",
                         "pregled.pdf");
        System.out.println("PDF generisan!");
    }
}
