public class Validator {

    public static boolean validanEmail(String email) {
        return email != null && email.matches("^[\\w.-]+@[\\w.-]+\\.\\w{2,}$");
    }

    public static boolean validnaLozinka(String lozinka) {
        if (lozinka == null) return false;
        return lozinka.length() >= 6;
    }

    public static void main(String[] args) {
        System.out.println("Email test (validan): " + validanEmail("korisnik@example.com"));
        System.out.println("Lozinka test (validna): " + validnaLozinka("tajna123"));
    }
}
