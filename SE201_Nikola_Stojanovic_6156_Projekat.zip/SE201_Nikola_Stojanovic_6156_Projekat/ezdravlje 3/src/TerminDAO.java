import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TerminDAO {

    private Connection conn;

    public TerminDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean zakaziTermin(int lekarId, int pacijentId, LocalDateTime datum) {
        String sql = "INSERT INTO TERMIN (LEKAR_ID, PACIJENT_ID, DATUM_VREME, STATUS) VALUES (?, ?, ?, 'zakazan')";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, lekarId);
            stmt.setInt(2, pacijentId);
            stmt.setString(3, datum.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Greška pri zakazivanju termina: " + e.getMessage());
            return false;
        }
    }

    public void prikaziTermineZaLekara(int lekarId) {
        String sql = "SELECT * FROM TERMIN WHERE LEKAR_ID = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, lekarId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("Termin ID: " + rs.getInt("ID") +
                        ", Pacijent ID: " + rs.getInt("PACIJENT_ID") +
                        ", Datum: " + rs.getString("DATUM_VREME") +
                        ", Status: " + rs.getString("STATUS"));
            }
        } catch (SQLException e) {
            System.out.println("Greška pri prikazu termina: " + e.getMessage());
        }
    }
}
