
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ObavestenjeDAO {

    private Connection conn;

    public ObavestenjeDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean posaljiObavestenje(String emailPrimaoca, String tekst) {
        String sql = "INSERT INTO OBAVESTENJE (EMAIL_PRIMAOCA, TEKST) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, emailPrimaoca);
            stmt.setString(2, tekst);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Greška pri slanju obaveštenja: " + e.getMessage());
            return false;
        }
    }

    public void prikaziSvaObavestenja() {
        String sql = "SELECT * FROM OBAVESTENJE";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("ID") +
                                   ", Email: " + rs.getString("EMAIL_PRIMAOCA") +
                                   ", Tekst: " + rs.getString("TEKST"));
            }
        } catch (SQLException e) {
            System.out.println("Greška pri prikazu obaveštenja: " + e.getMessage());
        }
    }
}
