import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {
        try {

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ezdravlje", "root", "");


            System.out.println("Validan email: " + Validator.validanEmail("test@gmail.com"));
            System.out.println("Validna lozinka: " + Validator.validnaLozinka("tajna123"));


            PDFGenerator.generisiIzvestaj("Petar Petrović", "Dr Ana Janković",
                    "Pregled je protekao uredno. Nema ozbiljnijih simptoma.",
                    "izvestaj_pregleda.pdf");


            TerminDAO terminDAO = new TerminDAO(conn);
            boolean uspehTermina = terminDAO.zakaziTermin(1, 2, LocalDateTime.now().plusDays(1));
            if (uspehTermina) System.out.println("Termin uspešno zakazan!");

            terminDAO.prikaziTermineZaLekara(1);


            ObavestenjeDAO obDAO = new ObavestenjeDAO(conn);
            boolean poslato = obDAO.posaljiObavestenje("test@gmail.com", "Vaš termin je zakazan za sutra u 12h.");
            if (poslato) System.out.println("Obaveštenje uspešno sačuvano!");

            obDAO.prikaziSvaObavestenja();


            EmailSender.posaljiEmail("primer@gmail.com", "Potvrda zakazanog termina", "Vaš termin je uspešno zakazan!");

        } catch (Exception e) {
            System.out.println("Greška u radu aplikacije: " + e.getMessage());
        }
    }
}
